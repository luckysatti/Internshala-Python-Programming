def Batting(player):
    points=0
    strike_rate=(player['runs']/player['balls'])*100
    points=points+(player['runs']//2)
    if player['runs']>=50:
        points=points+5
    if player['runs']>=100:
        points=points+10
    if strike_rate >=80 and strike_rate <=100:
        points=points+2
    elif strike_rate >100:
        points=points+4
    points=points+player['4']+(2*player['6'])
    result={'name':player['name'],'batscore':int(points)}
    return result
    
def Bowling(player):
    points=0
    bowl_scores=[]
    economy=player['runs']//player['overs']
    points=points+player['wkts']*10
    if player['wkts']==3:
        points=points+5
    elif player['wkts']>=5:
        points=points+10
    if economy >= 3.5 and economy<=4.5:
        points=points+4
    elif economy >= 2 and economy<=3.5:
        points=points+7
    elif economy < 2:
            points=points+10  
    result={'name':player['name'],'bowlscore':int(points)}
    return result

        
