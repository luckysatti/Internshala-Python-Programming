import sqlite3
MyBooks=sqlite3.connect('Books.db')
curbooks=MyBooks.cursor()
TotalCost=0
def Book_Requirement():
    global TotalCost
    BookTitle=input("Enter the title:")
    sql="SELECT * FROM BOOKS WHERE TITLE='"+BookTitle+"';"
    curbooks.execute(sql)
    record=curbooks.fetchone()
    print(record)
    BookQuantity=int(input("No of Books Required:"))
    AddMoreBooks=input("Add more books? Y/N:")
    if AddMoreBooks=='Y':
        TotalCost+=record[3]*BookQuantity
        Book_Requirement()
    else:
        TotalCost+=record[3]*BookQuantity
Book_Requirement()
print("Total Cost:",TotalCost)
        
        
    
