class book:
    def __init__(self,title,author,publisher,price,copies=0):
        self._title=title
        self._author=author
        self._publisher=publisher
        self._price=price
        self._copies=copies

    def get_title(self):
        return self._title
    def set_title(self,title):
        self._title=title
        return
    title=property(get_title,set_title)

    def get_author(self):
        return self._author
    def set_author(self,author):
        self._author=author
        return
    author=property(get_author,set_author)

    def get_publisher(self):
        return self._publisher
    def set_publisher(self,publisher):
        self._publisher=publisher
        return
    publisher=property(get_publisher,set_publisher)

    def get_price(self):
        return self._price
    def set_price(self,price):
        self._price=price
        return
    price=property(get_price,set_price)

    def get_copies(self):
        return self._copies
    def set_copies(self,copies):
        self._copies=copies
        return
    copies=property(get_copies,set_copies)

    def get_royalty(self):
        if self.copies<=500:
            self._royalty=self.copies*self.price*(10/100)
        elif self.copies<=1000:
            self._royalty=500*self.price*(10/100)+(self.copies-500)*self.price*(12.5/100)
        else:
            self._royalty=500*self.price*(10/100)+500*self.price*(12.5/100)+(self.copies-1000)*self.price*(15/100)
        return self._royalty
class ebook(book):
    def __init__(self,title,author,publisher,price,copies=0,format=None):
        super().__init__(title,author,publisher,price,copies)
        self.ebook_format=format
    def get_ebook_format(self):
        return self._ebook_format
    def set_ebook_format(self,format):
        self._ebook_format=format
        return
    ebook_format=property(get_ebook_format,set_ebook_format)
    def get_royalty(self):
        Royalty=super().get_royalty()
        Royalty=Royalty-Royalty*12/100
        self._Royalty=Royalty
        return self._Royalty
if __name__=="__main__":
    print('Book')
    Book1=book("Robinson Crusoe","Daniel Dafoe","SS Publications",250,750)
    print("Royalty:",Book1.get_royalty())
    print('EBook')
    EBook1=ebook("Robinson Crusoe","Daniel Dafoe","SS Publications",250,5,"PDF")
    print("Royalty:",EBook1.get_royalty())





    

